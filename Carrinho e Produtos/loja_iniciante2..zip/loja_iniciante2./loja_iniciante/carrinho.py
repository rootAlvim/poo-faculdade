from .Modelos import Produto
class Carrinho:
    def __init__(self):
        self.itens = [] 

    def adicionar(self,produto,quantidade = 1):
        self.itens.append((produto,quantidade))

    def remover(self,produto):
        for item in self.itens:
            if item[0] == produto:
                self.itens.remove(item)
                break #empacotado, dava pra desempacotar

    def itens_unicos(self):
        vistos = []
        for item in self.itens:
            if item[0].nome not in vistos:
                vistos.append(item[0].nome) 
        return vistos #empacotado, dava pra desempacotar
    
    def total(self):
        subtotal = 0
        for item in self.itens:
            subtotal +=  item[0].preco * item[1]
        return subtotal #empacotado , lidando com indices
    
    '''def total(self):
        subtotal = 0
        for produto, quantidade in self.itens:
            subtotal += produto.preco * quantidade
        return subtotal #sem empacotar '''

    def linhas_tabela(self):
        linhas = []
        for item in self.itens:
            sub = item[0].preco * item[1]
            linhas.append([item[0].nome,f"R$ {item[0].preco:.2f}",item[1],f"R$ {sub:.2f}"])
        return linhas #empacotado , lidando com indices
    
    '''def linhas_tabela(self): 
        linhas = [] 
        for produto, quantidade in self.itens: 
            sub = produto.preco * quantidade 
            linhas.append([produto.nome,f"R$ {produto.preco:.2f}",quantidade,f"R$ {sub:.2f}"]) 
        return linhas
'''
    

# ---------- Sobrecarga de operadores ----------
    def __add__(self,produto):
        novo = Carrinho()
        for item in self.itens:
            novo.itens.append(item)
        novo.adicionar(produto, 1)
        return novo

    def __sub__(self, produto):
        novo = Carrinho()
        for item in self.itens:
            novo.itens.append(item)
        novo.remover(produto)
        return novo
    
    def __iadd__(self, produto):
        self.adicionar(produto,1)
        return self        
    
    def __isub__(self, produto):
        self.remover(produto)
        return self

