class Produto:
    def __init__(self,nome:str,preco:float):
        self.nome = nome
        self.preco = preco

    def desconto(self,percentual):
        novo_preco = self.preco * (1 - percentual/100)
        return Produto(self.nome,novo_preco)
    
    def __mul__(self,quantidade:int):
        subtotal = self.preco * quantidade
        return subtotal
    
    def __repr__(self):
        return f"Produto(nome = '{self.nome}', preco = {self.preco:.2f}, Quantidade = )"

Produto("Lápis", 2.00).preco == 2.00
repr(Produto("Caderno", 12.50)) #no formato sugerido
Produto("Lápis", 2.00) * 3 == 6.00
Produto("Caderno", 100.00).desconto(10).preco == 90.00 #e mantém o nome
