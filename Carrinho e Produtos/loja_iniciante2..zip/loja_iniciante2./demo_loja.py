# demo_loja.py
"""
Demonstração da mini loja:
- POO com Produto e Carrinho
- Tabela com 'tabulate'
Instalação:
pip install tabulate
"""
from tabulate import tabulate
from loja_iniciante import Produto, Carrinho

def main():
    # Produtos
    caderno = Produto("Caderno 10 matérias", 12.50)
    lapis = Produto("Lápis", 2.00)
    borracha = Produto("Borracha", 1.50)
    promo_caderno = caderno.desconto(20)  # novo produto com 20% de desconto

    # Carrinho base
    carrinho3 = Carrinho()
    carrinho3.adicionar(caderno, 2)
    carrinho3.adicionar(lapis, 3)
    carrinho3.adicionar(borracha, 6)


    # Mostrar um carrinho final
    cabecalho = ["Produto", "Preço", "Qtd", "Subtotal"]
    print(tabulate(carrinho3.linhas_tabela(), headers=cabecalho, tablefmt="grid"))
    print("\nTotal carrinho 3: R$ {:.2f}".format(carrinho3.total()))
    print("Itens únicos carrinho 3:", carrinho3.itens_unicos())

if __name__ == "__main__":
    main()
